# kaprekarlab

A small, dependency-free Python toolkit for **Kaprekar numbers** and the **Kaprekar routine** (the famous constant **6174**), created by Parsa Daryabar (dev_nightmare) and students of Kamal School as a school project and shared so others can build on it.

> Named in honour of **D. R. Kaprekar** (1905–1986), the Indian schoolteacher who discovered these patterns.

## What are they?
* **Kaprekar number**: `n` such that splitting `n²` into two parts (right part > 0) and adding them gives `n`. Example: `45² = 2025 → 20 + 25 = 45`.
* **Kaprekar routine**: sort the digits descending and ascending, subtract, repeat. Every 4-digit number (not all digits equal) reaches **6174** in at most **7** steps; 3-digit numbers reach **495**.

## Install & try
```bash
pip install kaprekarlab          # from PyPI (Python 3.8+, no dependencies)
kaprekarlab routine 3524         # step-by-step walkthrough to 6174
kaprekarlab list 10000           # all Kaprekar numbers up to 10000
kaprekarlab analyze --digits 3   # constants, cycles, step histogram
kaprekarlab quiz -n 5            # practice questions
```
From source (for contributors):
```bash
git clone https://github.com/devnightmareee/kaprekarlab && cd kaprekarlab
pip install -e .
python -m unittest discover -s tests
```
```python
from kaprekarlab import is_kaprekar, routine, analyze, explain
is_kaprekar(297)                 # True
routine(3524).path               # (3524, 3087, 8352, 6174)
analyze(4).constants             # [6174]
analyze(2).attractors            # 2-digit numbers fall into the cycle 9→81→63→27→45
```

## Practical workflows
| You want to… | Do this |
|---|---|
| **Grade students' programs automatically** | A student writes `steps(n)` in `student.py` → `kaprekarlab grade student.py` checks it on all 8,991 four-digit inputs and lists mismatches |
| **Hand out practice sheets** | `kaprekarlab worksheet -n 10 --lang fa > sheet.md` (worksheet + answer key, Persian or English) |
| **Give students a tool with no Python** | `kaprekarlab html explorer.html` writes an offline interactive page |
| **Analyse in Excel / Sheets / pandas** | `kaprekarlab csv --digits 4 > data.csv` (start, steps, kind, attractor) |
| **Get edge-case inputs for tests** | `kaprekarlab worst` / `worst_cases()` → numbers needing the maximum 7 steps |
| **Cross-check another language** | `kaprekarlab vectors > vectors.json` → known answers for every number |
| **Script it** | `--json` on `routine` and `analyze` |
| **Draw figures for reports** | `kaprekarlab svg` (histogram) or `kaprekarlab svg --path 3524` |
| **Explore other bases / digit counts** | `is_kaprekar(n, base)`, `analyze(digits, base)` |
| **Play with random-number ideas** | `KaprekarRNG` (educational, not secure) · `kaprekar_hash` (toy, not cryptographic) |

> `grade` imports and runs the student's file — only grade code you trust.

## Contributing
Ideas welcome: new bases, faster algorithms, other languages (JS, C, Rust), classroom worksheets, better visualisations. Open an issue or a pull request and add tests.

## License
MIT © Parsa Daryabar (dev_nightmare) and kaprekarlab contributors

---
## فارسی
نصب: `pip install kaprekarlab` — سپس دستور `kaprekarlab routine 3524` را اجرا کنید یا در پایتون `from kaprekarlab import routine, is_kaprekar` را وارد کنید.

`kaprekarlab` یک جعبه‌ابزار سبک پایتون برای **اعداد کاپرکار** و **فرایند کاپرکار (ثابت ۶۱۷۴)** است؛ برای آموزش برنامه‌نویسی، تست الگوریتم‌ها، آزمایش‌های عددی، نمودار و پژوهش. هر مشارکتی خوش‌آمد است.
